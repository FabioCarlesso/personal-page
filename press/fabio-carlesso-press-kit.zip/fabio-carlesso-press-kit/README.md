# Fabio Carlesso — press kit

Free to use as is, for recruiters, event organisers and podcast hosts.
Latest version: https://fabiocarlesso.com/press.html

| folder | contents |
| --- | --- |
| `*.pdf` | the press kit as PDF, English and Portuguese |
| `bio/` | bios in three lengths (one-liner, short, long), `en` and `pt` |
| `photo/` | headshot — crop freely; don't filter, recolour or distort |
| `logos/svg/` | vector logos, text outlined to paths (no fonts needed) |
| `logos/png/` | the same logos at 4×, transparent background |

## Which logo

- `logo-fc` — primary, on dark surfaces · `logo-fc-light` — primary, on light surfaces
- `logo-fc-on-accent` — on the blue accent · `logo-stacked` — square spaces · `logo-wordmark` — banners, slides
- `logo-fc-mono-white` / `logo-fc-mono-ink` — one-colour use (dark / light)
- `logo-42` — the easter egg; never the primary mark

## Rules

- Do keep the parens of (fc) in signal blue `#58A6FF` on every colour variant.
- Do leave clear space around the mark of at least one paren's width.
- Don't recolour, stretch, rotate or add effects; don't retype (fc) in another typeface.

## Palette

| name | hex | use |
| --- | --- | --- |
| ink | `#0A0D10` | background |
| ink-2 | `#11161B` | cards, panels |
| blue | `#58A6FF` | accent · the parens |
| amber | `#E3B341` | 42 · highlights |
| rust | `#C8602A` | rare warm accent |
| paper | `#F5F1EA` | light surfaces |
| bone | `#FAFAF7` | text on dark |

Type: JetBrains Mono (display, headings, code) · IBM Plex Sans (body) · IBM Plex Serif italic (accents).
All three are free on Google Fonts.

## Contact

fabio.carlesso@gmail.com · linkedin.com/in/fabio-carlesso · github.com/FabioCarlesso
