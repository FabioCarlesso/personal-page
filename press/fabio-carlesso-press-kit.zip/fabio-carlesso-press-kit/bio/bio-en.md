# Fabio Carlesso — bio (en)

## one-liner

Fabio Carlesso is a senior backend engineer who has been shipping Java to production since 2010, mostly for the banking sector.

## short

Fabio Carlesso is a senior backend engineer based in Foz do Iguaçu, Brazil. Since 2010, Fabio has built and run Java systems in production — most of them in banking, where code has to be correct, auditable and debuggable at 3am. Day to day that means Spring Boot, AWS, Postgres and Docker. AWS Certified Cloud Practitioner.

## long

Fabio Carlesso is a senior backend software engineer with more than fifteen years of Java in production. The career started in 2010 on Java 6 and IBM WebSphere and runs through to Spring Boot 3 services in AWS containers. Since 2018 it has been in the banking sector, where systems run all night, sit under regulation and have to be debuggable by whoever is on call.

Fabio holds a B.S. in Computer Science, postgraduate specialisations in Java Technology and in Data Science & Big Data, and the AWS Certified Cloud Practitioner and EXIN Agile Scrum Foundation certifications. Outside the day job, Fabio designs, builds and runs independent products — FightOssStreak, Cartola Odds and the Carlesso Pilates platform — all live in production, all with public source code.

Based in Foz do Iguaçu, Brazil (GMT-3). Works in Portuguese and English.
