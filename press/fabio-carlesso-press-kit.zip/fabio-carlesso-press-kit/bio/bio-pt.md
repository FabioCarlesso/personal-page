# Fabio Carlesso — bio (pt)

## one-liner

Fabio Carlesso é engenheiro backend sênior e coloca Java em produção desde 2010, principalmente no setor bancário.

## short

Fabio Carlesso é engenheiro backend sênior, baseado em Foz do Iguaçu. Desde 2010 constrói e mantém sistemas Java em produção — a maioria no setor bancário, onde o código precisa ser correto, auditável e depurável às 3h da manhã. No dia a dia, isso significa Spring Boot, AWS, Postgres e Docker. Certificado AWS Cloud Practitioner.

## long

Fabio Carlesso é engenheiro de software backend sênior, com mais de quinze anos de Java em produção. A carreira começou em 2010, com Java 6 e IBM WebSphere, e chegou a serviços Spring Boot 3 em containers na AWS. Desde 2018 atua no setor bancário, onde os sistemas rodam a noite toda, estão sob regulação e precisam ser depuráveis por quem estiver de plantão.

É bacharel em Ciência da Computação, especialista em Tecnologia Java e em Data Science & Big Data, com as certificações AWS Certified Cloud Practitioner e EXIN Agile Scrum Foundation. Fora do trabalho, projeta, constrói e mantém produtos independentes — FightOssStreak, Cartola Odds e a plataforma Carlesso Pilates — todos em produção, todos com código público.

Baseado em Foz do Iguaçu (GMT-3). Trabalha em português e inglês.
